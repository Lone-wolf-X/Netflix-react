// Import the functions you need from the SDKs you need
// import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
export const firebaseConfig = {
  apiKey: "AIzaSyA_at5YGo4xdO25O9PJ-elg_Hv_pOXan-s",
  authDomain: "netflix-f4a7b.firebaseapp.com",
  projectId: "netflix-f4a7b",
  storageBucket: "netflix-f4a7b.appspot.com",
  messagingSenderId: "937795785465",
  appId: "1:937795785465:web:f86c295b0d04339795c828",
  measurementId: "G-NKW62MYTLP"
};

// Initialize Firebase
// const app = initializeApp(firebaseConfig);